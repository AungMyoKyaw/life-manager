# Life Manager — Logo and Brand Identity Specification

> **Decision status:** Q001–Q064 = A, all approved without overrides (2026-11-14).
> **Execution status:** DESIGN EXECUTED on 2026-11-14 after explicit user authorization. App code integration, commit, push and deployment remain outside scope. Results: `design/brand/VALIDATION_REPORT.md`.

## 1. Product and brand brief

- **Name:** Life Manager; wordmark in English, title case. Product name is locked for this identity brief. The existing provisional bundle identifier remains a separate product/release decision.
- **Product:** Local-first macOS personal productivity tool for tasks, calendar, goals, focus, habits, notes, reviews and controlled agent workflows. Core data and control remain on-device.
- **Promise:** Make multiple areas of life feel coherent while retaining the person's control over decisions, commitments and attention.
- **Audience:** Independent professionals, software developers and power users; do not make the mark developer-exclusive.
- **Positioning:** Premium desktop utility, not a social productivity service, wellness app or AI-first robot.
- **Personality:** Precise, calm, mature, intelligent, quietly confident; no urgency, gamification or motivational excess.
- **Primary target:** macOS application icon, with scalable standalone symbol and horizontal wordmark as related systems.

## 2. Art direction — Converging Paths

**Symbol narrative.** Multiple distinct paths become a coherent focal point, suggesting attention, agency and navigation through different life domains. It is an abstract mark with an identifiable silhouette, not a pictogram or monogram.

**Form.** Two or more purposeful solid geometric elements with softly engineered corners, controlled asymmetry, an intentional open/negative-space center, optical balancing and subtle implied movement. Flat forms and a compact silhouette must remain clear at 16–32 pixels. Avoid making the paths read as a generic checkmark, calendar box, clock face, AI sparkle, brain, robot, infinity loop, flower or common arrow logo.

**Three required explorations within this same concept:** (1) converging solid bands, (2) offset geometric channels, and (3) joined modules defining a central void. These are creative starting hypotheses, not preapproved final artwork; make geometry genuinely different, not merely recolored variants.

**Wordmark.** Life Manager, title case, refined macOS/system-compatible sans-serif in medium or semibold weight; custom kerning/spacing where justified. Preserve editability in the native master and verify reliable font handling for vector/PDF distribution. Use no decorative ligatures or faux futuristic lettering.

**Palette.** Use existing shared token source, design/scripts/tokens.py. Baseline light accent: #266C56; dark accent: #419677. Contextual colors include #112124 deep-green canvas and #F6F7F5 light canvas. Draw a single-brand-hue identity with supporting neutral colors; final accessible pairings must be verified, not guessed. Create purposeful light, dark, black, white and single-color variants. Do not require gradients, shadows, bevels, glass or 3D.

**Compositions.** Standalone symbol remains container-free. Only the macOS application icon uses a deliberate squircle-backed composition. Provide horizontal symbol + wordmark; menu bar and favicon get intentionally simplified variants, not blind downscaling of the Dock artwork.

## 3. Single source of truth and integration boundaries

1. **Canonical visual master:** design/life-manager-master.figcraft. The authorized future workflow may add a Brand Identity page, but must preserve every existing application page and board. Snapshot current frame names/counts and render references immediately before editing.
2. **Authoring pipeline:** use design/scripts design-generation workflow and figcraft-cli as applicable. All authored geometry must be real editable vectors/layers; inserting a flattened preview as the master is prohibited. Do not hand-edit a generated master in a way that the next rebuild discards.
3. **Tokens:** existing design/scripts/tokens.py remains authoritative for shared visual semantics. If new brand-specific design tokens are required, add them additively with light/dark behavior, rather than globally recoloring app screens.
4. **App integration:** existing sidebar split-circle is deprecated conceptually, but remains unchanged until an additional explicit integration authorization. The same applies to the Dock app-bundle icon, menu bar and README usage; deliverable files do not imply they are installed or wired into the app.
5. **Scope guard:** no modification to application source, runtime behavior, old design boards, business data, product schema, bundle identifier, dependencies, Git history or release pipeline as part of initial identity design.
6. **Git state:** the repository currently has extensive untracked files. Do not mistake that preexisting state for changes caused by this planning document, and do not commit/push as part of this phase.

## 4. Approved decision record

All 64 questions are independently preserved below. A = previously recommended selection approved with no overrides. Question IDs are stable. This record supersedes only overlapping **logo identity** assumptions; it does not silently authorize product rename, app code edits, or distribution changes.

### R1 — Brand strategy

| ID | Approved selection | State |
|---|---|---|
| Q001 | Life Manager is the brand name | A — locked |
| Q002 | Clarity, agency and control of personal time | A — locked |
| Q003 | Professionals, developers and power users | A — locked |
| Q004 | Precise, calm, mature and intelligent | A — locked |
| Q005 | Quiet confidence and focus | A — locked |
| Q006 | AI secondary to human control | A — locked |
| Q007 | Premium professional desktop utility | A — locked |
| Q008 | Timeless multi-year identity | A — locked |

### R2 — Symbol

| ID | Approved selection | State |
|---|---|---|
| Q009 | Custom symbol plus independent wordmark | A — locked |
| Q010 | Converging Paths is the shared creative direction | A — locked |
| Q011 | Original abstract geometric mark | A — locked |
| Q012 | Replace the existing split-circle identity rather than tracing it | A — locked |
| Q013 | Subtle, ownable meaning rather than obvious pictogram | A — locked |
| Q014 | Subtle implied progression | A — locked |
| Q015 | Few deliberate custom shapes | A — locked |
| Q016 | Avoid generic calendars, checkmarks, AI sparkles, brains, robots and infinity loops | A — locked |

### R3 — Construction

| ID | Approved selection | State |
|---|---|---|
| Q017 | Mathematical construction with optical corrections | A — locked |
| Q018 | Minimal but memorable silhouette | A — locked |
| Q019 | Solid forms and controlled negative space | A — locked |
| Q020 | Controlled asymmetry | A — locked |
| Q021 | Softly engineered corners | A — locked |
| Q022 | Deliberate opening / negative-space feature | A — locked |
| Q023 | Readability at 16–32 px | A — locked |
| Q024 | Standalone symbol; squircle container only for macOS application icon | A — locked |

### R4 — Color and type

| ID | Approved selection | State |
|---|---|---|
| Q025 | Evolve current forest-green design system | A — locked |
| Q026 | One primary brand hue plus neutral support | A — locked |
| Q027 | Flat vector colors, no necessary gradients | A — locked |
| Q028 | Purpose-designed light and dark variants | A — locked |
| Q029 | Black, white and single-color variants | A — locked |
| Q030 | Refined system-compatible sans-serif wordmark | A — locked |
| Q031 | Medium/semibold custom-spaced wordmark | A — locked |
| Q032 | English primary branding | A — locked |

### R5 — Applications

| ID | Approved selection | State |
|---|---|---|
| Q033 | Prioritize macOS application icon | A — locked |
| Q034 | Eventually replace existing sidebar mark after separate application integration approval | A — locked |
| Q035 | Simplified monochrome menu-bar mark | A — locked |
| Q036 | Optimize Dock/Finder readability and macOS icon conventions | A — locked |
| Q037 | Favicon-ready compact mark | A — locked |
| Q038 | Horizontal wordmark and standalone mark for GitHub/docs | A — locked |
| Q039 | Reusable README, release and future-website artwork | A — locked |
| Q040 | Keep symbol portable to future platforms | A — locked |

### R6 — FigCraft and output

| ID | Approved selection | State |
|---|---|---|
| Q041 | Brand Identity page in the single existing life-manager-master.figcraft | A — locked |
| Q042 | Editable native vector geometry, authored through existing design workflow and FigCraft CLI | A — locked |
| Q043 | Reuse shared design tokens; add brand-scoped tokens only if necessary | A — locked |
| Q044 | Native FigCraft vector master; SVG interchange | A — locked |
| Q045 | 1024, 512, 256, 128, 64, 32 and 16 px PNG plus ICNS | A — locked |
| Q046 | SVG, PNG, PDF and monochrome variants | A — locked |
| Q047 | Preserve all current boards and unrelated design components | A — locked |
| Q048 | Deterministic/repeatable CLI-driven generation and export | A — locked |

### R7 — Quality

| ID | Approved selection | State |
|---|---|---|
| Q049 | Review distinctiveness relative to familiar productivity iconography | A — locked |
| Q050 | Inspect at 16, 24, 32, 64, 128, 256, 512 and 1024 px | A — locked |
| Q051 | Test light, dark, transparent and colored backgrounds | A — locked |
| Q052 | Inspect optical as well as geometrical centering | A — locked |
| Q053 | Contrast and recognizable monochrome silhouette | A — locked |
| Q054 | FigCraft rendering, inspection and refinement of every meaningful variant | A — locked |
| Q055 | Validate dimensions, alpha/background, vector fidelity and readable exports | A — locked |
| Q056 | Pass originality, memorability, minimalism, scalability, alignment and consistency | A — locked |

### R8 — Review and governance

| ID | Approved selection | State |
|---|---|---|
| Q057 | Three materially distinct custom concept explorations | A — locked |
| Q058 | Show icon, wordmark, light/dark and Dock context per concept | A — locked |
| Q059 | Compare all three, recommend strongest and refine the selected direction | A — locked |
| Q060 | Iterate against acceptance criteria; record revisions | A — locked |
| Q061 | Custom original geometry and appropriately licensed fonts/assets | A — locked |
| Q062 | Preserve unrelated files; no commits, pushes or deployments without approval | A — locked |
| Q063 | FigCraft, SVG, PNG, ICNS, PDF, preview sheet, guidelines and validation report | A — locked |
| Q064 | Separate explicit authorization is required before any FigCraft construction or application integration | A — locked |
## 5. Executed design protocol (authorized 2026-11-14)

1. Capture read-only baseline: FigCraft page/frame/name inventory, screenshots or exports needed for visual regressions, existing sidebar mark and current token values.
2. Draw three native, truly differentiated Converging Paths constructions, each with standalone symbol, wordmark, squircle macOS treatment and light/dark sample. Keep options together in the new Brand Identity page.
3. Render all alternatives using FigCraft CLI. Review silhouette, negative space, distinctiveness, optical balance, and 16–32 px recognition. Document tradeoffs; select/recommend the strongest. Request/record concept selection before treating an option as final.
4. Refine the selected design and derive horizontal, symbol-only, menu bar, favicon, light/dark, black/white, and single-color versions. Run proportional, optical and small-pixel adjustments on each meaningful derivative.
5. Export genuine vector SVG/PDF and correct raster PNG sizes; build and validate a real .icns. Keep derivatives reproducible from the editable master.
6. Run the existing FigCraft design verification and before/after visual regression checks to demonstrate unrelated boards remain untouched. Document all tests and any caveats.
7. Create the final comparison sheet, usage guide, asset manifest and validation report. Do not integrate into app/UI or commit/push/deploy without a separate instruction.

**Proposed future paths (not created by this approval):** design/brand/exports/ for generated assets; design/brand/previews/ for comparisons; design/brand/BRAND_GUIDELINES.md; design/brand/VALIDATION_REPORT.md. Source-of-truth identity artwork remains in the canonical FigCraft master.

## 6. Acceptance gates (every gate must pass; no false success claims)

| Gate | Pass condition | Evidence for review |
|---|---|---|
| AC01 — Scope | Three geometrically distinct Converging Paths concepts; no alternative brand name or unrelated symbol theme | Concept sheet and source layer inventory |
| AC02 — Design choice | One preferred direction compared against the other two; selection and refinements recorded | Side-by-side decision record |
| AC03 — Native editability | Actual editable FigCraft vector objects, not a raster in a container; regenerated artwork is reproducible | FigCraft source/layer inspection and rebuild check |
| AC04 — Originality | Custom-drawn mark; no unmodified icon/library asset; comparative review of common productivity mark shapes; no claim of formal trademark clearance without it | Geometry provenance and distinctiveness notes |
| AC05 — Form | Memorable silhouette, open negative-space feature, optical corrections documented, no visible misalignment or unintended intersections | Full-resolution renders and geometry review |
| AC06 — Small sizes | Distinguishable at 16, 24 and 32 px without merged gaps or ambiguous pixels; also inspect 64/128/256/512/1024 px | Multi-size 1:1 preview sheet |
| AC07 — Color | Primary brand green derives from shared token; dark/light palettes intentional; consistent single-color marks; no required gradient effect | Token mapping and variant specimens |
| AC08 — Contrast | Meaningful in-app/icon-only controls target >=3:1 against adjacent backgrounds; branding-only surfaces evaluated for practical visibility; grayscale/monochrome clarity checked | Contrast calculations and sample renders |
| AC09 — Surface coverage | Test white, light canvas, dark canvas, green and transparent backgrounds; no illegible color collisions | Background comparison matrix |
| AC10 — macOS icon | Balanced, centered optical weight in squircle; appropriate padding; icon recognizable in Dock and Finder-like contexts | Mockups at several sizes |
| AC11 — Wordmark | Correct “Life Manager” lettering, spacing, font availability/licensing, clear horizontal lockup and standalone mark | Wordmark specimen and font provenance |
| AC12 — Derivatives | Dedicated menu-bar monochrome mark, favicon and horizontal/standalone versions; no blind resizing of detailed artwork | Asset matrix |
| AC13 — PNG | Exactly 1024, 512, 256, 128, 64, 32 and 16 px square PNGs; visually sharp at target pixel sizes | Dimensions/alpha/format validation |
| AC14 — Vector/PDF | SVG and PDF open without errors, preserve intended vector edges and correct geometry, and have expected backgrounds | Parse/import/render comparison |
| AC15 — ICNS | Real macOS .icns bundle generated and parseable; required icon sizes present | iconutil-based validation or equivalent macOS inspection |
| AC16 — Existing master | Existing boards remain present and unaltered after adding the new Brand Identity page; no lost frames/styles/variables; baseline and after screenshots agree | FigCraft inventories + design visual regression report |
| AC17 — Shared tokens | New design binds to existing or additive brand tokens; changes do not unintentionally recolor unrelated screens | Token inspection and regression check |
| AC18 — Repeatability | Documented regeneration creates matching exported geometry, files and dimensions without manual steps | CLI generation/validation commands and results |
| AC19 — Delivery | Native FigCraft art, SVG, PNG, ICNS, PDF, concept preview, guidance and written QA/asset manifest all present | Output tree plus openability checks |
| AC20 — Governance | No unauthorized app edits, deployment, commit, push, rename or unrelated changes | Scoped file-change manifest and repository review |

If any gate fails, correct in editable source and rerun the affected checks; explicitly disclose any remaining unverified test or nonblocking limitation rather than claiming perfection. Legal trademark clearance is outside these technical/design gates and cannot be represented as completed by visual comparison alone.

## 7. Dependency reconciliation / constraints

- **Q010 + Q057:** Three differentiated geometry explorations, one Converging Paths narrative.
- **Q012 + Q034 + Q047:** Replace the old symbol only after separate app integration authorization, not while generating logo concepts. Current boards preserved.
- **Q024 + Q033 + Q036:** Standalone container-free logo is the reusable mark; macOS-app squircle is an application-specific composition.
- **Q025 + Q028 + Q029 + Q043:** One core green identity; light/dark and monochrome variants adapt as needed. Shared app tokens are not overwritten by logo experiment colors.
- **Q041 + Q042 + Q048:** New Brand Identity page must be generated through authoritative scripts/CLI so future master rebuilds preserve it.
- **Q045 + Q046 + Q050 + Q063:** Exported PNG sizes are seven specified sizes; additional 24 px is a mandatory QA inspection scale, not necessarily a separately shipped export. PDF/SVG and other derivatives are independent of the PNG matrix.
- **Q059 + Q060 + Q064:** Approval of the specification is not permission to draw, export, change the app or commit. Future execution may create and present concepts, but final concept selection is recorded before producing final assets.
- **Q001 + existing product decision ledger:** “Life Manager” is approved for this identity. The product-level provisional bundle identifier and unrelated provider questions remain unchanged.
- **Q049 + Q061:** Distinctiveness review and permitted assets reduce avoidable resemblance/licensing risk, but are not formal legal trademark opinions.

## 8. Architecture-readiness review

**Design brief:** COMPLETE — all 64 selected defaults approved; no unresolved requirements block a future design pass.

**Identity design execution:** COMPLETED — three concepts created, Concept B selected, native artwork rendered and validated, export package produced. See `design/brand/VALIDATION_REPORT.md` for tests and limitations.

**Remaining scope restrictions:** Logo assets and the canonical FigCraft page are created. Application code/sidebar integration, commits, pushes and deployment have not been authorized or performed.

**Next optional task:** Integrate the approved logo into the macOS app bundle, sidebar, menu bar and documentation in a separate authorized implementation task.
